class Makanan {
  String nama;
  int harga;
  String deskripsi;
  String gambar; // path gambar

  Makanan({
    required this.nama,
    required this.harga,
    required this.deskripsi,
    required this.gambar,
  });
}

// Daftar makanan
List<Makanan> daftarMakanan = [
  Makanan(
    nama: "Seblak",
    harga: 12000,
    deskripsi: "Seblak pedas khas Bandung dengan kerupuk renyah dan topping sosis.",
    gambar: "assets/images/seblak.jpeg",
  ),
  Makanan(
    nama: "Nasi Goreng Daging",
    harga: 15000,
    deskripsi: "Nasi goreng dengan irisan daging sapi, bumbu rempah lezat.",
    gambar: "assets/images/nasidaging.jpeg",
  ),
  Makanan(
    nama: "Nasi Kuning ",
    harga: 13000,
    deskripsi: "Nasi kuning gurih lengkap dengan ayam suwir dan telur.",
    gambar: "assets/images/nasikuning.jpeg",
  ),
  Makanan(
    nama: "Cireng",
    harga: 8000,
    deskripsi: "Camilan khas Sunda yang renyah di luar dan kenyal di dalam.",
    gambar: "assets/images/cireng.jpeg",
  ),
  Makanan(
    nama: "Ramen",
    harga: 25000,
    deskripsi: "Mie ramen kuah pedas gurih dengan topping telur dan daging.",
    gambar: "assets/images/ramen.jpeg",
  ),
  // 🆕 Tambahan 1 menu baru
  Makanan(
    nama: "Bakso Urat Jumbo",
    harga: 20000,
    deskripsi: "Bakso urat ukuran besar dengan kuah kaldu sapi kental dan sambal pedas.",
    gambar: "assets/images/bakso.jpeg",
  ),
];

import 'package:flutter/material.dart';
import 'package:pertemuan5/model/makanan_model.dart';
import 'package:pertemuan5/screen/halaman_detail.dart';

class HalamanUtama extends StatelessWidget {
  const HalamanUtama({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 255, 65, 65),
      appBar: AppBar(
        title: const Text("Menu Hari Ini apa chef ?"),
        backgroundColor: Colors.redAccent,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: daftarMakanan.length, // ambil dari list model
        itemBuilder: (context, index) {
          final makanan = daftarMakanan[index];
          return Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            elevation: 4,
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  makanan.gambar,
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                ),
              ),
              title: Text(
                makanan.nama,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              subtitle: Text("Rp ${makanan.harga}"),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HalamanDetail(i: index),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

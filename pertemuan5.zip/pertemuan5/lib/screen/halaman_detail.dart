import 'package:flutter/material.dart';
import 'package:pertemuan5/model/makanan_model.dart';

class HalamanDetail extends StatelessWidget {
  final int i; // Gunakan final agar sesuai untuk StatelessWidget
  const HalamanDetail({super.key, required this.i});

  @override
  Widget build(BuildContext context) {
    // Ambil data makanan dari list berdasarkan index
    final makanan = daftarMakanan[i];

    return Scaffold(
      appBar: AppBar(
        title: Text("Detail ${makanan.nama}"),
        backgroundColor: Colors.redAccent,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Gambar produk
            Image.asset(
              makanan.gambar,
              height: 250,
              width: double.infinity,
              fit: BoxFit.cover,
            ),

            const SizedBox(height: 20),

            // Nama produk
            Text(
              makanan.nama,
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            // Harga
            Text(
              "Harga: Rp ${makanan.harga}",
              style: const TextStyle(
                fontSize: 20,
                color: Colors.green,
              ),
            ),

            const SizedBox(height: 20),

            // Deskripsi
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                makanan.deskripsi,
                style: const TextStyle(fontSize: 16, height: 1.5),
                textAlign: TextAlign.center,
              ),
            ),

            const SizedBox(height: 30),

            // Tombol tambah ke keranjang
            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("${makanan.nama} ditambahkan ke keranjang!")),
                );
              },
              icon: const Icon(Icons.shopping_cart),
              label: const Text("Tambah ke Keranjang"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
